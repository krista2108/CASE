﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TMC_case_team4.Data;

namespace TMC_case_team4.Pages.MainPages
{
    /// <summary>
    /// Логика взаимодействия для PageMainMenu.xaml
    /// </summary>
    public partial class PageMainMenu : Page
    {
        public PageMainMenu()
        {
            InitializeComponent();
        }

        private void btn_responsible_persons_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageResponsePers());
        }

        private void btn_products_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageProduct());
        }

        private void btn_product_map_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageProductCard());
        }

        private void btn_destinations_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageNaznachenie());
        }

        private void btn_duide_Click(object sender, RoutedEventArgs e)
        {
            FrameApp.frmObj.Navigate(new PageGuide());
        }
    }
}
