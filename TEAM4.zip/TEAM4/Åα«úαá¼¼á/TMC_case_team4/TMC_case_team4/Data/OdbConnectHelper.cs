﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TMC_case_team4.Data
{
    class OdbConnectHelper
    {
        public static Inventory_ItemsEntities entObj;
    }
}
